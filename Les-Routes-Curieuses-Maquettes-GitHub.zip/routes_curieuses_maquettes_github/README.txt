Les Routes Curieuses — maquettes HTML

Ces fichiers sont les maquettes exportées, renommées avec des noms simples.
index.html est la page d'accueil.

Pour les déposer dans GitHub :
1. Ouvrir le dépôt.
2. Cliquer sur Add file > Upload files.
3. Extraire ce ZIP sur l'ordinateur.
4. Glisser les six fichiers HTML dans GitHub (ne pas déposer seulement le ZIP).
5. Cliquer sur Commit changes.

Important : il s'agit de maquettes exportées, pas encore d'une version de production entièrement vérifiée. Il faudra tester les liens et l'affichage après leur dépôt.
